import TextCutout from "./text-cutout"

interface CutoutSectionTitleProps {
  title: string
  subtitle: string
  backgroundPattern?: "dots" | "lines" | "waves" | "gradient" | "noise"
  backgroundImage?: string
  align?: "left" | "center" | "right"
  theme?: "light" | "dark"
}

export default function CutoutSectionTitle({
  title,
  subtitle,
  backgroundPattern = "gradient",
  backgroundImage,
  align = "center",
  theme = "light",
}: CutoutSectionTitleProps) {
  const textColor = theme === "light" ? "text-black" : "text-[#F2E2D7]"
  const mutedTextColor = theme === "light" ? "text-black/70" : "text-[#F2E2D7]/70"

  const alignmentClasses = {
    left: "text-left",
    center: "text-center mx-auto",
    right: "text-right ml-auto",
  }

  return (
    <div className={`max-w-3xl mb-16 ${alignmentClasses[align]}`}>
      <h2 className={`text-sm tracking-[0.2em] uppercase mb-2 font-light ${textColor}`}>{subtitle}</h2>

      <TextCutout
        text={title}
        backgroundPattern={backgroundPattern}
        backgroundImage={backgroundImage}
        className="h-[80px] md:h-[120px] flex items-center"
        textClassName={`text-3xl md:text-5xl lg:text-6xl font-serif ${alignmentClasses[align]}`}
        animate={true}
      />
    </div>
  )
}
