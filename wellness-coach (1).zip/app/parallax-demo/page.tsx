import ParallaxSection from "@/components/parallax-section"
import ParallaxTestimonials from "@/components/parallax-testimonials"
import ParallaxServices from "@/components/parallax-services"

export default function ParallaxDemo() {
  return (
    <main className="min-h-screen">
      <ParallaxSection />
      <ParallaxTestimonials />
      <ParallaxServices />
    </main>
  )
}
