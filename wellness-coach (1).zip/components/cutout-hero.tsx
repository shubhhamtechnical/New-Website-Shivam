"use client"

import { useEffect, useRef, useState } from "react"
import TextCutout from "./text-cutout"

export default function CutoutHero() {
  const [scrollY, setScrollY] = useState(0)
  const sectionRef = useRef<HTMLDivElement>(null)
  const [inView, setInView] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect()
        const isInView = rect.top < window.innerHeight && rect.bottom > 0

        if (isInView) {
          setInView(true)
          setScrollY(window.scrollY)
        } else if (inView) {
          setInView(false)
        }
      }
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    handleScroll() // Check initial position

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [inView])

  return (
    <section
      ref={sectionRef}
      className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-[#000000] py-20"
    >
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-[url('/noise-pattern.png')] bg-repeat"></div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-[1px] bg-[#F2E2D7]/10"></div>
      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-[#F2E2D7]/10"></div>
      <div className="absolute top-0 left-1/4 w-[1px] h-full bg-[#F2E2D7]/5"></div>
      <div className="absolute top-0 right-1/4 w-[1px] h-full bg-[#F2E2D7]/5"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-5xl mx-auto">
          {/* Main heading with cut-out effect */}
          <div className="mb-12 relative">
            <TextCutout
              text="TRANSFORM YOUR LIFE"
              backgroundPattern="noise"
              className="h-[120px] md:h-[180px] flex items-center justify-center mb-6"
              textClassName="text-5xl md:text-7xl lg:text-8xl font-bold text-center tracking-tight"
              animate={true}
            />

            <div className="relative h-[120px] md:h-[180px] flex items-center justify-center overflow-hidden">
              <TextCutout
                text="WITH MINDFUL COACHING"
                backgroundImage="/serene-wellness-coach.png"
                className="h-full w-full"
                textClassName="text-5xl md:text-7xl lg:text-8xl font-bold text-center tracking-tight"
                animate={true}
              />
            </div>
          </div>

          {/* Subtitle */}
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-[#F2E2D7] text-lg md:text-xl mb-8 leading-relaxed">
              Embark on a transformative journey to discover your true potential and create a life of purpose and
              fulfillment.
            </p>

            <button className="px-8 py-3 bg-[#F2E2D7] text-black rounded-full text-sm font-medium tracking-wide hover:bg-[#F2E2D7]/90 transition-all duration-300 relative">
              Begin Your Journey
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
