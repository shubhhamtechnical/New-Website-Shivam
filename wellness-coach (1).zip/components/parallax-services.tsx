"use client"

import { useEffect, useRef, useState } from "react"
import { Users, BookOpen, Mic } from "lucide-react"

export default function ParallaxServices() {
  const [scrollY, setScrollY] = useState(0)
  const sectionRef = useRef<HTMLDivElement>(null)
  const [inView, setInView] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect()
        const isInView = rect.top < window.innerHeight && rect.bottom > 0

        if (isInView) {
          setInView(true)
          setScrollY(window.scrollY)
        } else if (inView) {
          setInView(false)
        }
      }
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    handleScroll() // Check initial position

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [inView])

  // Calculate parallax positions based on scroll
  const calculateParallax = (speed: number) => {
    if (!inView) return 0
    return scrollY * speed
  }

  const services = [
    {
      icon: <Users className="h-8 w-8" />,
      title: "One-on-One Coaching",
      description: "Personalized coaching sessions tailored to your unique needs and goals.",
      color: "bg-[#000000]",
      textColor: "text-[#F2E2D7]",
    },
    {
      icon: <Mic className="h-8 w-8" />,
      title: "Motivational Speaking",
      description: "Engaging talks designed to inspire and empower your team or organization.",
      color: "bg-[#F2E2D7]",
      textColor: "text-black",
    },
    {
      icon: <BookOpen className="h-8 w-8" />,
      title: "Published Works",
      description: "Transformative books and resources to guide your personal development journey.",
      color: "bg-[#000000]",
      textColor: "text-[#F2E2D7]",
    },
  ]

  return (
    <section ref={sectionRef} className="relative py-24 overflow-hidden bg-gradient-to-b from-[#000000] to-[#0a0b14]">
      {/* Background decorative elements with parallax */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-0 left-0 w-full h-[1px] bg-[#F2E2D7]/10"
          style={{ transform: `translateY(${calculateParallax(0.05)}px)` }}
        ></div>
        <div
          className="absolute bottom-0 left-0 w-full h-[1px] bg-[#F2E2D7]/10"
          style={{ transform: `translateY(${calculateParallax(-0.05)}px)` }}
        ></div>

        {/* Vertical lines */}
        <div
          className="absolute top-0 left-1/4 w-[1px] h-full bg-[#F2E2D7]/5"
          style={{ transform: `translateX(${calculateParallax(0.02)}px)` }}
        ></div>
        <div
          className="absolute top-0 right-1/4 w-[1px] h-full bg-[#F2E2D7]/5"
          style={{ transform: `translateX(${calculateParallax(-0.02)}px)` }}
        ></div>

        {/* Floating shapes */}
        <div
          className="absolute top-[20%] left-[10%] w-40 h-40 rounded-full bg-[#F2E2D7]/5 blur-xl"
          style={{ transform: `translate(${calculateParallax(0.03)}px, ${calculateParallax(0.05)}px)` }}
        ></div>
        <div
          className="absolute bottom-[15%] right-[5%] w-60 h-60 rounded-full bg-[#F2E2D7]/3 blur-xl"
          style={{ transform: `translate(${calculateParallax(-0.04)}px, ${calculateParallax(-0.06)}px)` }}
        ></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2
            className="text-[#F2E2D7] text-sm tracking-[0.2em] uppercase mb-2 font-light"
            style={{
              transform: `translateY(${calculateParallax(-0.05)}px)`,
              opacity: inView ? 1 : 0.5,
              transition: "opacity 0.5s ease-in-out",
            }}
          >
            What I Offer
          </h2>
          <h3
            className="font-serif text-3xl md:text-4xl lg:text-5xl mb-6 text-[#F2E2D7]"
            style={{
              transform: `translateY(${calculateParallax(-0.08)}px)`,
              opacity: inView ? 1 : 0.5,
              transition: "opacity 0.5s ease-in-out 0.2s",
            }}
          >
            Premium Services
          </h3>
          <p
            className="text-[#F2E2D7]/70"
            style={{
              transform: `translateY(${calculateParallax(-0.1)}px)`,
              opacity: inView ? 1 : 0.5,
              transition: "opacity 0.5s ease-in-out 0.3s",
            }}
          >
            Discover the range of services designed to help you achieve your full potential and transform your life.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          {services.map((service, index) => (
            <div
              key={index}
              className={`${service.color} p-8 rounded-lg shadow-lg relative overflow-hidden group`}
              style={{
                transform: `translateY(${calculateParallax(-0.1 * (index + 1))}px)`,
                opacity: inView ? 1 : 0.5,
                transition: `all 0.5s ease-in-out ${0.2 + index * 0.2}s`,
              }}
            >
              {/* Background pattern */}
              <div className="absolute inset-0 opacity-5">
                <div className="absolute top-0 left-0 w-full h-full bg-[url('/chromatic-flow.png')] bg-repeat opacity-10"></div>
              </div>

              {/* Decorative corner wires */}
              <div className="absolute top-0 left-0 w-[20px] h-[1px] bg-[#F2E2D7]/20"></div>
              <div className="absolute top-0 left-0 w-[1px] h-[20px] bg-[#F2E2D7]/20"></div>
              <div className="absolute top-0 right-0 w-[20px] h-[1px] bg-[#F2E2D7]/20"></div>
              <div className="absolute top-0 right-0 w-[1px] h-[20px] bg-[#F2E2D7]/20"></div>
              <div className="absolute bottom-0 left-0 w-[20px] h-[1px] bg-[#F2E2D7]/20"></div>
              <div className="absolute bottom-0 left-0 w-[1px] h-[20px] bg-[#F2E2D7]/20"></div>
              <div className="absolute bottom-0 right-0 w-[20px] h-[1px] bg-[#F2E2D7]/20"></div>
              <div className="absolute bottom-0 right-0 w-[1px] h-[20px] bg-[#F2E2D7]/20"></div>

              <div className="relative z-10">
                <div
                  className={`w-16 h-16 ${service.color === "bg-[#000000]" ? "bg-[#F2E2D7]/10" : "bg-black/10"} rounded-full flex items-center justify-center mb-6 relative group-hover:scale-110 transition-transform duration-300`}
                >
                  <div className={service.textColor}>{service.icon}</div>
                  {/* Circular wire element */}
                  <div className="absolute inset-0 border border-[#F2E2D7]/10 rounded-full"></div>
                </div>
                <h4 className={`font-serif text-xl mb-4 ${service.textColor}`}>{service.title}</h4>
                <p className={`${service.color === "bg-[#000000]" ? "text-[#F2E2D7]/70" : "text-black/70"}`}>
                  {service.description}
                </p>
                <div className="mt-6">
                  <button
                    className={`px-4 py-2 ${service.color === "bg-[#000000]" ? "bg-[#F2E2D7] text-black" : "bg-black text-[#F2E2D7]"} rounded-full text-sm font-medium tracking-wide hover:opacity-90 transition-all duration-300 relative`}
                  >
                    Learn More
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
