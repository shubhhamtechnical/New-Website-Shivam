"use client"

import { useState } from "react"
import Image from "next/image"

interface ImageEnhancerProps {
  src: string
  alt: string
  width?: number
  height?: number
  fill?: boolean
  className?: string
  enhanceLevel?: "light" | "medium" | "strong"
}

export default function ImageEnhancer({
  src,
  alt,
  width,
  height,
  fill = false,
  className = "",
  enhanceLevel = "medium",
}: ImageEnhancerProps) {
  const [isLoaded, setIsLoaded] = useState(false)

  // Define enhancement filters based on level
  const getEnhancementStyle = () => {
    switch (enhanceLevel) {
      case "light":
        return {
          filter: "contrast(1.05) brightness(1.02) saturate(1.05)",
        }
      case "strong":
        return {
          filter: "contrast(1.15) brightness(1.1) saturate(1.2) sharpen(1)",
        }
      case "medium":
      default:
        return {
          filter: "contrast(1.1) brightness(1.05) saturate(1.1)",
        }
    }
  }

  return (
    <div className={`relative ${className} overflow-hidden`}>
      {/* Enhancement overlay */}
      <div
        className={`absolute inset-0 z-10 transition-opacity duration-300 ${isLoaded ? "opacity-100" : "opacity-0"}`}
        style={{
          background:
            "linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0) 50%, rgba(0,0,0,0.05) 100%)",
          mixBlendMode: "overlay",
        }}
      ></div>

      {/* Main image with enhancement filters */}
      <Image
        src={src || "/placeholder.svg"}
        alt={alt}
        width={width}
        height={height}
        fill={fill}
        className={`${className} transition-opacity duration-500 ${isLoaded ? "opacity-100" : "opacity-0"}`}
        style={getEnhancementStyle()}
        onLoad={() => setIsLoaded(true)}
        quality={90}
      />

      {/* Loading placeholder */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-gray-200 animate-pulse" style={{ backdropFilter: "blur(8px)" }}></div>
      )}
    </div>
  )
}
