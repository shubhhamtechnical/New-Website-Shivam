"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageSquare } from "lucide-react"

export default function EnquiryForm() {
  const openWhatsApp = () => {
    window.open(`https://wa.me/919259686545?text=Hello, I'm interested in your coaching services.`, "_blank")
  }

  return (
    <div className="w-full max-w-md mx-auto">
      <Card className="border-black shadow-lg bg-[#F2E2D7]">
        <CardHeader className="bg-[#000000] text-[#F2E2D7]">
          <CardTitle className="text-2xl font-serif">Get In Touch</CardTitle>
          <CardDescription className="text-[#F2E2D7]/90">Contact via WhatsApp for enquiries</CardDescription>
        </CardHeader>

        <CardContent className="pt-6 pb-6">
          <div className="text-center py-4">
            <p className="text-black mb-6">
              For coaching enquiries, book consultations, or any questions, please reach out directly via WhatsApp.
            </p>
            <div
              onClick={openWhatsApp}
              className="flex items-center justify-center gap-2 p-3 border border-green-600 text-green-600 rounded-md cursor-pointer hover:bg-green-50"
            >
              <MessageSquare className="h-4 w-4 text-green-600" />
              <span>WhatsApp: +91 9259686545</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
