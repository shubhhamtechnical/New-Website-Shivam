"use client"

import Image from "next/image"
import Link from "next/link"
import { Star, Shield, Award, Instagram, Facebook, BookOpen, Users, Mic } from "lucide-react"
import WhatsAppWidget from "@/components/whatsapp-widget"
import ContactForm from "@/components/contact-form"
import CommunityWidget from "@/components/community-widget"
import CommunitySection from "@/components/community-section"
import PaymentButton from "@/components/payment-button"

export default function Home() {
  // Define the new turquoise white color to replace black
  const turquoiseWhite = "#E0F7F6"

  return (
    <div className="min-h-screen bg-[#F2E2D7] text-black relative">
      {/* WhatsApp Widget */}
      <WhatsAppWidget />

      {/* Community Widget */}
      <CommunityWidget />

      {/* Rest of the code remains the same */}
      {/* Decorative Wire Elements */}
      <div className="hidden md:block absolute top-0 right-0 w-1/3 h-screen pointer-events-none overflow-hidden">
        <div className="absolute top-[10%] right-[10%] w-[1px] h-[30%] bg-white/10"></div>
        <div className="absolute top-[15%] right-[20%] w-[1px] h-[40%] bg-white/5"></div>
        <div className="absolute top-[5%] right-[30%] w-[1px] h-[20%] bg-white/8"></div>
      </div>

      <div className="hidden md:block absolute top-0 left-0 w-1/3 h-screen pointer-events-none overflow-hidden">
        <div className="absolute top-[20%] left-[10%] w-[1px] h-[40%] bg-white/10"></div>
        <div className="absolute top-[30%] left-[20%] w-[1px] h-[30%] bg-white/5"></div>
        <div className="absolute top-[10%] left-[25%] w-[1px] h-[20%] bg-white/8"></div>
      </div>

      {/* Horizontal Wire Elements */}
      <div className="hidden md:block absolute top-[30%] left-0 w-full h-[1px] bg-white/5 pointer-events-none"></div>
      <div className="hidden md:block absolute top-[60%] left-0 w-full h-[1px] bg-white/8 pointer-events-none"></div>
      <div className="hidden md:block absolute top-[90%] left-0 w-full h-[1px] bg-white/3 pointer-events-none"></div>

      {/* Header with Logo Only */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-[#F2E2D7]/90 to-transparent backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-center relative">
            {/* Decorative wire elements around logo */}
            <div className="absolute top-1/2 left-1/4 w-[30%] h-[1px] bg-white/10 transform -translate-y-1/2 hidden md:block"></div>
            <div className="absolute top-1/2 right-1/4 w-[30%] h-[1px] bg-white/10 transform -translate-y-1/2 hidden md:block"></div>

            <Link href="/" className="flex items-center relative z-10">
              <Image src="/happierwomen_logo.png" alt="Happier Women Logo" width={180} height={60} className="h-auto" />
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-24 bg-[#F2E2D7] overflow-hidden">
        <div className="absolute top-1/2 left-0 w-full h-[1px] bg-white/5 transform -translate-y-1/2 hidden md:block"></div>
        <div className="absolute top-0 left-1/2 w-[1px] h-full bg-white/5 transform -translate-x-1/2 hidden md:block"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="relative h-[400px] md:h-[500px] rounded-lg overflow-hidden">
              {/* Decorative corner wires */}
              <div className="absolute top-0 left-0 w-[20px] h-[1px] bg-white/30"></div>
              <div className="absolute top-0 left-0 w-[1px] h-[20px] bg-white/30"></div>
              <div className="absolute top-0 right-0 w-[20px] h-[1px] bg-white/30"></div>
              <div className="absolute top-0 right-0 w-[1px] h-[20px] bg-white/30"></div>
              <div className="absolute bottom-0 left-0 w-[20px] h-[1px] bg-white/30"></div>
              <div className="absolute bottom-0 left-0 w-[1px] h-[20px] bg-white/30"></div>
              <div className="absolute bottom-0 right-0 w-[20px] h-[1px] bg-white/30"></div>
              <div className="absolute bottom-0 right-0 w-[1px] h-[20px] bg-white/30"></div>

              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/motovatinal-8I3bqzpEWrBfcSSWUbk4US8ZpblUhQ.jpeg"
                alt="Professional Event"
                fill
                className="object-cover object-center rounded-lg"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[#0a0b14]/30 to-transparent"></div>
            </div>

            <div className="max-w-xl relative">
              {/* Decorative wire element */}
              <div className="absolute top-0 left-0 w-[40px] h-[1px] bg-white/20"></div>

              <h5 className="text-black text-sm md:text-base tracking-[0.2em] uppercase mb-4 font-light">
                How can I help you as a Life Coach?
              </h5>
              <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl leading-tight mb-6">
                Achieve <span className="text-black">Happiness</span> and Fulfilment
              </h1>
              <ul className="text-black text-sm md:text-base space-y-2 mb-8 max-w-lg">
                <li className="flex items-start">
                  <span className="text-black mr-2">•</span>
                  <span>Replace limiting beliefs with empowering ones</span>
                </li>
                <li className="flex items-start">
                  <span className="text-black mr-2">•</span>
                  <span>Discover your unique strengths</span>
                </li>
                <li className="flex items-start">
                  <span className="text-black mr-2">•</span>
                  <span>Learn techniques for better decision-making</span>
                </li>
                <li className="flex items-start">
                  <span className="text-black mr-2">•</span>
                  <span>Create healthy relationships</span>
                </li>
                <li className="flex items-start">
                  <span className="text-black mr-2">•</span>
                  <span>Journey through self-reflection to unlock potential</span>
                </li>
                <li className="flex items-start">
                  <span className="text-black mr-2">•</span>
                  <span>Develop a positive mindset</span>
                </li>
                <li className="flex items-start">
                  <span className="text-black mr-2">•</span>
                  <span>Identify and overcome stress triggers</span>
                </li>
                <li className="flex items-start">
                  <span className="text-black mr-2">•</span>
                  <span>Create roadmaps to achieve your goals</span>
                </li>
              </ul>

              {/* Decorative wire element */}
              <div className="absolute bottom-0 right-0 w-[60px] h-[1px] bg-white/20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Ready to Begin Section - Added after hero */}
      <section className="py-20 bg-[#E0F7F6] relative">
        <div className="absolute top-0 left-1/2 w-[1px] h-[40px] bg-black/10 transform -translate-x-1/2"></div>
        <div className="absolute bottom-0 left-1/2 w-[1px] h-[40px] bg-black/10 transform -translate-x-1/2"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-black text-sm tracking-[0.2em] uppercase mb-2 font-light">READY TO BEGIN</h2>
            <h3 className="font-serif text-3xl md:text-4xl lg:text-5xl mb-6 text-black">
              Elevate Your Experience Today
            </h3>
            <p className="text-black/80 mb-12 text-lg">
              Take the first step towards experiencing our premium services. Our team of experts is ready to guide you
              through a journey of excellence.
            </p>

            <div className="max-w-md mx-auto bg-[#D1F2F0] p-8 rounded-lg border border-black/10 relative">
              {/* Decorative corner wires */}
              <div className="absolute top-0 left-0 w-[20px] h-[1px] bg-black/20"></div>
              <div className="absolute top-0 left-0 w-[1px] h-[20px] bg-black/20"></div>
              <div className="absolute top-0 right-0 w-[20px] h-[1px] bg-black/20"></div>
              <div className="absolute top-0 right-0 w-[1px] h-[20px] bg-black/20"></div>
              <div className="absolute bottom-0 left-0 w-[20px] h-[1px] bg-black/20"></div>
              <div className="absolute bottom-0 left-0 w-[1px] h-[20px] bg-black/20"></div>
              <div className="absolute bottom-0 right-0 w-[20px] h-[1px] bg-black/20"></div>
              <div className="absolute bottom-0 right-0 w-[1px] h-[20px] bg-black/20"></div>

              <h4 className="font-serif text-2xl text-black mb-4">Get In Touch</h4>
              <p className="text-black/80 mb-6">Fill out the form below and we'll get back to you shortly</p>

              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* One-on-One Coaching Section */}
      <section id="coaching" className="py-24 bg-[#E0F7F6] relative">
        <div className="absolute top-0 left-1/2 w-[1px] h-[40px] bg-black/10 transform -translate-x-1/2"></div>
        <div className="absolute bottom-0 left-1/2 w-[1px] h-[40px] bg-black/10 transform -translate-x-1/2"></div>

        <div className="container mx-auto px-4 relative">
          <div className="text-center max-w-3xl mx-auto mb-16 relative">
            {/* Decorative wire elements */}
            <div className="absolute top-1/2 left-0 w-[10%] h-[1px] bg-black/10 transform -translate-y-1/2 hidden md:block"></div>
            <div className="absolute top-1/2 right-0 w-[10%] h-[1px] bg-black/10 transform -translate-y-1/2 hidden md:block"></div>

            <div className="w-16 h-16 bg-[#D1F2F0] rounded-full flex items-center justify-center mb-6 mx-auto relative">
              <Users className="h-8 w-8 text-black" />
              {/* Circular wire element */}
              <div className="absolute inset-0 border border-black/10 rounded-full"></div>
            </div>
            <h2 className="text-black text-sm tracking-[0.2em] uppercase mb-2 font-light">Life Coach</h2>
            <h3 className="font-serif text-3xl md:text-4xl lg:text-5xl mb-6 text-black">One-on-One Coaching With Me</h3>
          </div>

          <div className="max-w-4xl mx-auto">
            <p className="text-black/80 text-lg mb-6 text-center">
              To help you take control of your life so that you become happier and discover your potential. I create
              customized programs so that the coaching plan directly addresses your unique needs, goals, circumstances &
              challenges, ensuring a focused and effective approach to achieving 'OUTCOMES'.
            </p>
            <p className="text-black/80 text-lg mb-8 text-center">
              So get ready with me so that I can help you 'RE-DESIGN YOUR LIFE.'
            </p>

            <div className="bg-[#D1F2F0] p-8 rounded-lg border border-black/10 mt-12 relative">
              {/* Decorative corner wires */}
              <div className="absolute top-0 left-0 w-[30px] h-[1px] bg-black/20 transform translate-y-[-1px] translate-x-[-1px]"></div>
              <div className="absolute top-0 left-0 w-[1px] h-[30px] bg-black/20 transform translate-y-[-1px] translate-x-[-1px]"></div>
              <div className="absolute top-0 right-0 w-[30px] h-[1px] bg-black/20 transform translate-y-[-1px] translate-x-[1px]"></div>
              <div className="absolute top-0 right-0 w-[1px] h-[30px] bg-black/20 transform translate-y-[-1px] translate-x-[1px]"></div>
              <div className="absolute bottom-0 left-0 w-[30px] h-[1px] bg-black/20 transform translate-y-[1px] translate-x-[-1px]"></div>
              <div className="absolute bottom-0 left-0 w-[1px] h-[30px] bg-black/20 transform translate-y-[1px] translate-x-[-1px]"></div>
              <div className="absolute bottom-0 right-0 w-[30px] h-[1px] bg-black/20 transform translate-y-[1px] translate-x-[1px]"></div>
              <div className="absolute bottom-0 right-0 w-[1px] h-[30px] bg-black/20 transform translate-y-[1px] translate-x-[1px]"></div>

              <h4 className="font-serif text-2xl mb-6 text-center text-black">How My Coaching Process Works</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center relative">
                  <div className="w-12 h-12 bg-[#C0EBE9] rounded-full flex items-center justify-center mb-4 mx-auto relative">
                    <span className="text-black font-serif text-xl">1</span>
                    {/* Circular wire element */}
                    <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                  </div>
                  <h5 className="font-serif text-lg mb-2 text-black">Assessment</h5>
                  <p className="text-black/70 text-sm">Understanding your unique needs and challenges</p>
                </div>
                <div className="text-center relative">
                  <div className="w-12 h-12 bg-[#C0EBE9] rounded-full flex items-center justify-center mb-4 mx-auto relative">
                    <span className="text-black font-serif text-xl">2</span>
                    {/* Circular wire element */}
                    <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                  </div>
                  <h5 className="font-serif text-lg mb-2 text-black">Customization</h5>
                  <p className="text-black/70 text-sm">Creating a personalized program tailored to your goals</p>
                </div>
                <div className="text-center relative">
                  <div className="w-12 h-12 bg-[#C0EBE9] rounded-full flex items-center justify-center mb-4 mx-auto relative">
                    <span className="text-black font-serif text-xl">3</span>
                    {/* Circular wire element */}
                    <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                  </div>
                  <h5 className="font-serif text-lg mb-2 text-black">Transformation</h5>
                  <p className="text-black/70 text-sm">Achieving outcomes and redesigning your life</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Community Section - Add before Motivational Speaker section */}
      <CommunitySection />

      {/* Motivational Speaker Section */}
      <section id="speaking" className="py-24 bg-[#F2E2D7] relative">
        <div className="absolute top-0 left-1/2 w-[1px] h-[40px] bg-white/10 transform -translate-x-1/2"></div>
        <div className="absolute bottom-0 left-1/2 w-[1px] h-[40px] bg-white/10 transform -translate-x-1/2"></div>

        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16 relative">
            {/* Decorative wire elements */}
            <div className="absolute top-1/2 left-0 w-[10%] h-[1px] bg-white/10 transform -translate-y-1/2 hidden md:block"></div>
            <div className="absolute top-1/2 right-0 w-[10%] h-[1px] bg-white/10 transform -translate-y-1/2 hidden md:block"></div>

            <div className="w-16 h-16 bg-black/10 rounded-full flex items-center justify-center mb-6 mx-auto relative">
              <Mic className="h-8 w-8 text-black" />
              {/* Circular wire element */}
              <div className="absolute inset-0 border border-white/10 rounded-full"></div>
            </div>
            <h2 className="text-black text-sm tracking-[0.2em] uppercase mb-2 font-light">Inspirational</h2>
            <h3 className="font-serif text-3xl md:text-4xl lg:text-5xl mb-6">Motivational Speaker</h3>
          </div>

          {/* Fix the layout to prevent overlapping */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-black text-lg mb-6">
                As a Motivational speaker I have spoken at various organisations like ONGC, Times of India, Lion's
                International club, Rotary club, Quantum University and more.
              </p>
              <p className="text-black text-lg mb-8">
                Book me for a 90 min session, designed specially for women who want tools, techniques and actionable
                plans for a happier and fulfilling life.
              </p>

              <div className="bg-[#E0F7F6] p-6 rounded-lg border border-black/10 relative">
                {/* Decorative corner wires */}
                <div className="absolute top-0 left-0 w-[20px] h-[1px] bg-black/20 transform translate-y-[-1px] translate-x-[-1px]"></div>
                <div className="absolute top-0 left-0 w-[1px] h-[20px] bg-black/20 transform translate-y-[-1px] translate-x-[-1px]"></div>
                <div className="absolute top-0 right-0 w-[20px] h-[1px] bg-black/20 transform translate-y-[-1px] translate-x-[1px]"></div>
                <div className="absolute top-0 right-0 w-[1px] h-[20px] bg-black/20 transform translate-y-[-1px] translate-x-[1px]"></div>
                <div className="absolute bottom-0 left-0 w-[20px] h-[1px] bg-black/20 transform translate-y-[1px] translate-x-[-1px]"></div>
                <div className="absolute bottom-0 left-0 w-[1px] h-[20px] bg-black/20 transform translate-y-[1px] translate-x-[-1px]"></div>
                <div className="absolute bottom-0 right-0 w-[20px] h-[1px] bg-black/20 transform translate-y-[1px] translate-x-[1px]"></div>
                <div className="absolute bottom-0 right-0 w-[1px] h-[20px] bg-black/20 transform translate-y-[1px] translate-x-[1px]"></div>

                <h4 className="font-serif text-xl mb-4 text-black">Featured Speaking Topics</h4>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-[#D1F2F0] rounded-full flex items-center justify-center mr-3 mt-1 relative">
                      <span className="text-black text-xs">✓</span>
                      {/* Circular wire element */}
                      <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                    </div>
                    <p className="text-black/80">Redesigning Your Life for Happiness</p>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-[#D1F2F0] rounded-full flex items-center justify-center mr-3 mt-1 relative">
                      <span className="text-black text-xs">✓</span>
                      {/* Circular wire element */}
                      <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                    </div>
                    <p className="text-black/80">Discovering Your Hidden Potential</p>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-[#D1F2F0] rounded-full flex items-center justify-center mr-3 mt-1 relative">
                      <span className="text-black text-xs">✓</span>
                      {/* Circular wire element */}
                      <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                    </div>
                    <p className="text-black/80">Transforming Challenges into Opportunities</p>
                  </li>
                </ul>
              </div>
            </div>

            <div className="flex justify-center w-full">
              <div className="relative mx-auto max-w-md">
                <div className="aspect-[4/5] relative z-10 w-full">
                  {/* Direct image implementation with proper styling */}
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/aboutimage-BTK2wI0tx3yjaMBjqyl9ZahOUj9m76.jpeg"
                    alt="Charu Lata Gupta - Motivational Speaker"
                    width={500}
                    height={625}
                    className="object-cover rounded-lg shadow-lg mx-auto"
                    style={{
                      filter: "contrast(1.05) brightness(1.05)",
                    }}
                    priority
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Author Section */}
      <section id="book" className="py-24 bg-[#E0F7F6] relative">
        <div className="absolute top-0 left-1/2 w-[1px] h-[40px] bg-black/10 transform -translate-x-1/2"></div>
        <div className="absolute bottom-0 left-1/2 w-[1px] h-[40px] bg-black/10 transform -translate-x-1/2"></div>

        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16 relative">
            {/* Decorative wire elements */}
            <div className="absolute top-1/2 left-0 w-[10%] h-[1px] bg-black/10 transform -translate-y-1/2 hidden md:block"></div>
            <div className="absolute top-1/2 right-0 w-[10%] h-[1px] bg-black/10 transform -translate-y-1/2 hidden md:block"></div>

            <div className="w-16 h-16 bg-[#D1F2F0] rounded-full flex items-center justify-center mb-6 mx-auto relative">
              <BookOpen className="h-8 w-8 text-black" />
              {/* Circular wire element */}
              <div className="absolute inset-0 border border-black/10 rounded-full"></div>
            </div>
            <h2 className="text-black text-sm tracking-[0.2em] uppercase mb-2 font-light">Published Author</h2>
            <h3 className="font-serif text-3xl md:text-4xl lg:text-5xl mb-6 text-black">Check Out My Book!</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="relative">
              {/* Decorative wire element */}
              <div className="absolute top-0 left-0 w-[40px] h-[1px] bg-black/20"></div>

              <h4 className="font-serif text-2xl mb-4 text-black">Secrets to Happiness... That No One Told You</h4>
              <p className="text-black/80 mb-6">
                In my book "Secrets to happiness...that no one told you," I have written proven strategies that can be
                implemented to create a happy & fulfilled life. At the end of each chapter, there are "@ Action Plans"
                and blank lines, where the readers can actually journal their thoughts, plans, beliefs, goals etc.
              </p>
              <p className="text-black/80 mb-6">
                The strategies given in the book, if applied, are guaranteed to take the reader from an unhappy state of
                mind to that of a joyful one, from negative thoughts to positive ones, from disempowering beliefs to
                empowering ones, from an empty life to a fulfilled one and from a victim mindset to a victor attitude.
              </p>
              <p className="text-black/80 mb-8">
                The book is a manual for practical tools and techniques that will help you overcome challenges and live
                a happier life.
              </p>

              <a
                href="https://www.amazon.in/dp/936452117X?ref=myi_title_dp"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 bg-[#F2E2D7] text-black rounded-full text-sm font-medium tracking-wide hover:shadow-lg hover:shadow-[#F2E2D7]/20 transition-all duration-300 relative"
              >
                <span className="relative z-10">Buy on Amazon</span>
                {/* Button wire frame */}
                <div className="absolute inset-0 border border-black/10 rounded-full"></div>
              </a>

              {/* Decorative wire element */}
              <div className="absolute bottom-0 right-0 w-[60px] h-[1px] bg-black/20"></div>
            </div>

            <div className="flex justify-center">
              <div className="relative max-w-md">
                <div className="absolute inset-0 bg-gradient-to-r from-[#F2E2D7]/20 to-[#F2E2D7]/20 blur-xl rounded-lg transform -rotate-3"></div>
                <div className="relative z-10 p-2 bg-[#D1F2F0] rounded-lg transform rotate-3 shadow-xl">
                  {/* Decorative corner wires */}
                  <div className="absolute top-0 left-0 w-[20px] h-[1px] bg-black/30"></div>
                  <div className="absolute top-0 left-0 w-[1px] h-[20px] bg-black/30"></div>
                  <div className="absolute top-0 right-0 w-[20px] h-[1px] bg-black/30"></div>
                  <div className="absolute top-0 right-0 w-[1px] h-[20px] bg-black/30"></div>
                  <div className="absolute bottom-0 left-0 w-[20px] h-[1px] bg-black/30"></div>
                  <div className="absolute bottom-0 left-0 w-[1px] h-[20px] bg-black/30"></div>
                  <div className="absolute bottom-0 right-0 w-[20px] h-[1px] bg-black/30"></div>
                  <div className="absolute bottom-0 right-0 w-[1px] h-[20px] bg-black/30"></div>

                  <Image
                    src="/book.jpg"
                    alt="Secrets to Happiness Book Cover"
                    width={400}
                    height={400}
                    className="rounded-md"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Button Section */}
      <section className="py-24 bg-[#F2E2D7] relative">
        <div className="absolute top-0 left-1/2 w-[1px] h-[40px] bg-white/10 transform -translate-x-1/2"></div>
        <div className="absolute bottom-0 left-1/2 w-[1px] h-[40px] bg-white/10 transform -translate-x-1/2"></div>

        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16 relative">
            {/* Decorative wire elements */}
            <div className="absolute top-1/2 left-0 w-[10%] h-[1px] bg-white/10 transform -translate-y-1/2 hidden md:block"></div>
            <div className="absolute top-1/2 right-0 w-[10%] h-[1px] bg-white/10 transform -translate-y-1/2 hidden md:block"></div>

            <h2 className="text-black text-sm tracking-[0.2em] uppercase mb-2 font-light">Secure Payments</h2>
            <h3 className="font-serif text-3xl md:text-4xl lg:text-5xl mb-6 text-black">Simple & Convenient Payment</h3>
            <p className="text-black/70">
              Complete your transaction securely and effortlessly with our premium payment options.
            </p>
          </div>

          <div className="relative">
            {/* Decorative wire frame */}
            <div className="absolute inset-0 border border-white/10 rounded-lg"></div>
            <PaymentButton />
          </div>
        </div>
      </section>

      {/* Quality Badges Section */}
      <section className="py-12 bg-[#F2E2D7] border-t border-gray-300 relative">
        <div className="absolute top-0 left-1/2 w-[1px] h-[20px] bg-white/10 transform -translate-x-1/2"></div>

        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-center items-center space-y-6 md:space-y-0 md:space-x-16">
            <div className="flex items-center">
              <div className="relative">
                <Star className="h-8 w-8 text-black mr-3" />
                {/* Circular wire element */}
                <div className="absolute inset-0 border border-white/10 rounded-full"></div>
              </div>
              <div>
                <h4 className="font-serif text-xl text-black">Premium Quality</h4>
                <p className="text-sm text-black/60">Uncompromising excellence</p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="relative">
                <Shield className="h-8 w-8 text-black mr-3" />
                {/* Circular wire element */}
                <div className="absolute inset-0 border border-white/10 rounded-full"></div>
              </div>
              <div>
                <h4 className="font-serif text-xl text-black">Trusted Service</h4>
                <p className="text-sm text-black/60">Reliable and consistent</p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="relative">
                <Award className="h-8 w-8 text-black mr-3" />
                {/* Circular wire element */}
                <div className="absolute inset-0 border border-white/10 rounded-full"></div>
              </div>
              <div>
                <h4 className="font-serif text-xl text-black">Award Winning</h4>
                <p className="text-sm text-black/60">Industry recognized</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Simplified Footer with Social Media Links */}
      <footer className="bg-[#E0F7F6] py-16 relative">
        <div className="absolute top-0 left-1/2 w-[1px] h-[40px] bg-black/10 transform -translate-x-1/2"></div>

        {/* Decorative wire grid */}
        <div className="absolute inset-0 grid grid-cols-6 pointer-events-none">
          {[...Array(7)].map((_, i) => (
            <div key={i} className="h-full w-[1px] bg-black/5" style={{ left: `${i * (100 / 6)}%` }}></div>
          ))}
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col items-center justify-center text-center">
            <Link href="/" className="mb-6 relative">
              <Image src="/happierwomen_logo.png" alt="Happier Women Logo" width={150} height={50} className="h-auto" />
              {/* Decorative wire element */}
              <div className="absolute -bottom-4 left-1/2 w-[40px] h-[1px] bg-black/10 transform -translate-x-1/2"></div>
            </Link>
            <p className="text-black/70 max-w-md mb-8">
              Providing exceptional premium services with uncompromising attention to detail and quality.
            </p>

            <div className="text-center mb-8">
              <p className="text-black/70 text-sm mb-1">charu765@gmail.com</p>
              <p className="text-black/70 text-sm">WhatsApp: +91 9259686545</p>
            </div>

            {/* Social Media Links - Fixed visibility */}
            <div className="flex space-x-6 mb-8">
              <a
                href="https://www.instagram.com/happierwomen/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#D1F2F0] flex items-center justify-center hover:bg-[#C0EBE9] transition-all relative"
              >
                <Instagram className="h-5 w-5 text-black" />
                {/* Circular wire element */}
                <div className="absolute inset-0 border border-black/10 rounded-full"></div>
              </a>
              <a
                href="https://www.facebook.com/share/1AAWoLjTW1/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#D1F2F0] flex items-center justify-center hover:bg-[#C0EBE9] transition-all relative"
              >
                <Facebook className="h-5 w-5 text-black" />
                {/* Circular wire element */}
                <div className="absolute inset-0 border border-black/10 rounded-full"></div>
              </a>
            </div>

            <div className="border-t border-black/10 pt-8 w-full">
              <p className="text-black/50 text-sm text-center">
                &copy; {new Date().getFullYear()} All rights reserved. Designed by websurface
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
