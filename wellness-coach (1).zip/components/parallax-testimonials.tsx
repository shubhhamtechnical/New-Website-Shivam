"use client"

import { useEffect, useRef, useState } from "react"
import { Star } from "lucide-react"

export default function ParallaxTestimonials() {
  const [scrollY, setScrollY] = useState(0)
  const sectionRef = useRef<HTMLDivElement>(null)
  const [inView, setInView] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect()
        const isInView = rect.top < window.innerHeight && rect.bottom > 0

        if (isInView) {
          setInView(true)
          setScrollY(window.scrollY)
        } else if (inView) {
          setInView(false)
        }
      }
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    handleScroll() // Check initial position

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [inView])

  // Calculate parallax positions based on scroll
  const calculateParallax = (speed: number) => {
    if (!inView) return 0
    return scrollY * speed
  }

  const testimonials = [
    {
      quote:
        "The coaching sessions have completely transformed my approach to life's challenges. I've gained clarity and confidence I never thought possible.",
      author: "Sarah M.",
      role: "Business Owner",
    },
    {
      quote:
        "Working with this coach has been the best investment in myself. The personalized guidance helped me break through limiting beliefs that were holding me back for years.",
      author: "Priya K.",
      role: "Marketing Executive",
    },
    {
      quote:
        "I was skeptical at first, but the results speak for themselves. I've achieved goals I once thought were impossible, all thanks to these transformative coaching sessions.",
      author: "Anjali R.",
      role: "Healthcare Professional",
    },
  ]

  return (
    <section ref={sectionRef} className="relative py-24 overflow-hidden bg-[#F2E2D7]" id="content-after-parallax">
      {/* Background decorative elements with parallax */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-[10%] right-[5%] w-64 h-64 rounded-full bg-black/5"
          style={{ transform: `translateY(${calculateParallax(0.1)}px)` }}
        ></div>
        <div
          className="absolute bottom-[15%] left-[10%] w-80 h-80 rounded-full bg-black/3"
          style={{ transform: `translateY(${calculateParallax(0.15)}px)` }}
        ></div>

        {/* Decorative lines */}
        <div
          className="absolute top-0 left-1/4 w-[1px] h-[30%] bg-black/10"
          style={{ transform: `translateY(${calculateParallax(0.05)}px)` }}
        ></div>
        <div
          className="absolute bottom-0 right-1/3 w-[1px] h-[40%] bg-black/10"
          style={{ transform: `translateY(${calculateParallax(0.08)}px)` }}
        ></div>
        <div
          className="absolute top-1/2 left-0 w-[20%] h-[1px] bg-black/10"
          style={{ transform: `translateY(${calculateParallax(0.12)}px)` }}
        ></div>
        <div
          className="absolute top-[70%] right-0 w-[15%] h-[1px] bg-black/10"
          style={{ transform: `translateY(${calculateParallax(0.07)}px)` }}
        ></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2
            className="text-black text-sm tracking-[0.2em] uppercase mb-2 font-light"
            style={{
              transform: `translateY(${calculateParallax(-0.05)}px)`,
              opacity: inView ? 1 : 0.5,
              transition: "opacity 0.5s ease-in-out",
            }}
          >
            Client Experiences
          </h2>
          <h3
            className="font-serif text-3xl md:text-4xl lg:text-5xl mb-6 text-black"
            style={{
              transform: `translateY(${calculateParallax(-0.08)}px)`,
              opacity: inView ? 1 : 0.5,
              transition: "opacity 0.5s ease-in-out 0.2s",
            }}
          >
            Transformative Journeys
          </h3>
          <p
            className="text-black/70"
            style={{
              transform: `translateY(${calculateParallax(-0.1)}px)`,
              opacity: inView ? 1 : 0.5,
              transition: "opacity 0.5s ease-in-out 0.3s",
            }}
          >
            Hear from those who have experienced the power of personalized coaching and transformed their lives.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-lg shadow-lg border border-black/5 relative"
              style={{
                transform: `translateY(${calculateParallax(-0.05 * (index + 1))}px)`,
                opacity: inView ? 1 : 0.5,
                transition: `opacity 0.5s ease-in-out ${0.2 + index * 0.2}s`,
              }}
            >
              {/* Decorative corner wires */}
              <div className="absolute top-0 left-0 w-[20px] h-[1px] bg-black/20"></div>
              <div className="absolute top-0 left-0 w-[1px] h-[20px] bg-black/20"></div>
              <div className="absolute top-0 right-0 w-[20px] h-[1px] bg-black/20"></div>
              <div className="absolute top-0 right-0 w-[1px] h-[20px] bg-black/20"></div>
              <div className="absolute bottom-0 left-0 w-[20px] h-[1px] bg-black/20"></div>
              <div className="absolute bottom-0 left-0 w-[1px] h-[20px] bg-black/20"></div>
              <div className="absolute bottom-0 right-0 w-[20px] h-[1px] bg-black/20"></div>
              <div className="absolute bottom-0 right-0 w-[1px] h-[20px] bg-black/20"></div>

              <div className="flex items-center mb-6">
                <div className="flex text-black">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-black/80 italic mb-6">"{testimonial.quote}"</p>
              <div className="mt-6">
                <p className="font-medium text-black">{testimonial.author}</p>
                <p className="text-sm text-black/60">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
