"use client"

import { useState, useEffect } from "react"
import { MessageCircle, X } from "lucide-react"

export default function WhatsAppWidget() {
  const [isVisible, setIsVisible] = useState(false)
  const [isOpen, setIsOpen] = useState(false)

  // Show widget after scrolling down a bit
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setIsVisible(true)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleWhatsAppClick = () => {
    window.open(`https://wa.me/919259686545?text=Hello, I'm interested in your coaching services.`, "_blank")
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {isOpen && (
        <div className="mb-4 bg-white rounded-lg shadow-lg overflow-hidden animate-fade-in w-72">
          <div className="bg-green-500 p-4 flex items-center">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mr-3">
              <MessageCircle className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-white font-medium">Charu Lata Gupta</h3>
              <p className="text-white/80 text-sm">Typically replies within an hour</p>
            </div>
          </div>

          <div className="p-4 bg-[#f0f0f0]">
            <p className="text-gray-700 text-sm mb-4">
              Hello! 👋 How can I help you today? Feel free to reach out for any coaching inquiries.
            </p>

            <button
              onClick={handleWhatsAppClick}
              className="w-full py-2 px-4 bg-green-500 hover:bg-green-600 text-white rounded-md flex items-center justify-center transition-colors"
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              Start Chat
            </button>
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center justify-center w-16 h-16 rounded-full shadow-lg transition-all duration-300 ${
          isOpen ? "bg-red-500 rotate-90" : "bg-green-500 hover:bg-green-600"
        }`}
      >
        {isOpen ? <X className="h-8 w-8 text-white" /> : <MessageCircle className="h-8 w-8 text-white" />}

        {/* Pulse effect when closed */}
        {!isOpen && <span className="absolute w-full h-full rounded-full bg-green-500 animate-ping opacity-75"></span>}
      </button>
    </div>
  )
}
