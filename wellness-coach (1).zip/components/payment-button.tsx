import { CreditCard } from "lucide-react"

export default function PaymentButton() {
  return (
    <div className="w-full max-w-md mx-auto text-center">
      <div className="bg-[#E0F7F6] p-8 rounded-lg shadow-lg border border-black/10 relative overflow-hidden">
        {/* Decorative corner wires */}
        <div className="absolute top-0 left-0 w-[20px] h-[1px] bg-black/20"></div>
        <div className="absolute top-0 left-0 w-[1px] h-[20px] bg-black/20"></div>
        <div className="absolute top-0 right-0 w-[20px] h-[1px] bg-black/20"></div>
        <div className="absolute top-0 right-0 w-[1px] h-[20px] bg-black/20"></div>
        <div className="absolute bottom-0 left-0 w-[20px] h-[1px] bg-black/20"></div>
        <div className="absolute bottom-0 left-0 w-[1px] h-[20px] bg-black/20"></div>
        <div className="absolute bottom-0 right-0 w-[20px] h-[1px] bg-black/20"></div>
        <div className="absolute bottom-0 right-0 w-[1px] h-[20px] bg-black/20"></div>

        <h3 className="font-serif text-2xl mb-4 text-black">Secure Payment Options</h3>
        <p className="text-black/80 mb-6">
          Complete your payment securely through our trusted payment gateway. We accept credit cards, debit cards, UPI,
          and more.
        </p>

        <a
          href="https://imjo.in/jzcqxA"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center px-6 py-3 bg-[#000000] text-[#F2E2D7] rounded-md hover:bg-black/80 transition-colors"
        >
          <CreditCard className="h-5 w-5 mr-2" />
          <span>Make Payment</span>
        </a>

        <p className="text-black/60 text-sm mt-4">You will be redirected to our secure payment gateway</p>
      </div>
    </div>
  )
}
