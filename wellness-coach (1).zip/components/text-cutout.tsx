"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { cn } from "@/lib/utils"

interface TextCutoutProps {
  text: string
  backgroundImage?: string
  backgroundPattern?: "dots" | "lines" | "waves" | "gradient" | "noise"
  className?: string
  textClassName?: string
  backgroundClassName?: string
  children?: React.ReactNode
  as?: React.ElementType
  animate?: boolean
}

export default function TextCutout({
  text,
  backgroundImage,
  backgroundPattern = "gradient",
  className,
  textClassName,
  backgroundClassName,
  children,
  as: Component = "h2",
  animate = false,
}: TextCutoutProps) {
  const [isInView, setIsInView] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!animate) {
      setIsInView(true)
      return
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsInView(true)
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current)
      }
    }
  }, [animate])

  // Generate background pattern based on the selected type
  const getBackgroundStyle = () => {
    switch (backgroundPattern) {
      case "dots":
        return {
          backgroundImage: "radial-gradient(#000 1px, transparent 1px), radial-gradient(#000 1px, transparent 1px)",
          backgroundSize: "20px 20px",
          backgroundPosition: "0 0, 10px 10px",
        }
      case "lines":
        return {
          backgroundImage: "linear-gradient(45deg, #000 25%, transparent 25%, transparent 75%, #000 75%, #000)",
          backgroundSize: "20px 20px",
        }
      case "waves":
        return {
          backgroundImage:
            "repeating-radial-gradient(circle at 0 0, transparent 0, #F2E2D7 10px), repeating-linear-gradient(#00000055, #000)",
        }
      case "noise":
        return {
          backgroundImage: "url('/noise-pattern.png')",
          backgroundSize: "200px 200px",
        }
      case "gradient":
      default:
        return {
          background: "linear-gradient(135deg, #000 0%, #333 100%)",
        }
    }
  }

  return (
    <div
      ref={ref}
      className={cn("relative overflow-hidden", className)}
      style={{
        opacity: isInView ? 1 : 0,
        transform: isInView ? "translateY(0)" : "translateY(20px)",
        transition: "opacity 0.8s ease, transform 0.8s ease",
      }}
    >
      {/* Background layer that will show through the text */}
      <div
        className={cn("absolute inset-0 z-0", backgroundClassName)}
        style={{
          ...(backgroundImage
            ? { backgroundImage: `url(${backgroundImage})`, backgroundSize: "cover", backgroundPosition: "center" }
            : getBackgroundStyle()),
        }}
      />

      {/* Text with cut-out effect */}
      <Component
        className={cn(
          "relative z-10 font-serif text-transparent bg-clip-text leading-tight",
          animate && "animate-reveal",
          textClassName,
        )}
        style={{
          WebkitBackgroundClip: "text", // For Safari support
          backgroundImage: "linear-gradient(to right, #F2E2D7, #F2E2D7)",
          color: "transparent",
        }}
      >
        {text}
      </Component>

      {/* Optional children content */}
      {children}
    </div>
  )
}
