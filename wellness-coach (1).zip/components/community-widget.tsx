"use client"

import { useState, useEffect } from "react"
import { Users, X, Lightbulb } from "lucide-react"

export default function CommunityWidget() {
  const [isVisible, setIsVisible] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)

  // Show widget after scrolling down a bit
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setIsVisible(true)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleJoinClick = () => {
    window.open("https://chat.whatsapp.com/CXywwWRIoJz7K61E0uqE2V", "_blank")
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-24 right-6 z-50 flex flex-col items-end">
      {isExpanded && (
        <div className="mb-4 bg-white rounded-lg shadow-lg overflow-hidden animate-fade-in w-72">
          <div className="bg-green-500 p-4 flex items-center">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mr-3">
              <Users className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-white font-medium">Join Our Community</h3>
              <p className="text-white/80 text-sm">Connect with expert mentorship</p>
            </div>
          </div>

          <div className="p-4 bg-[#f0f0f0]">
            <p className="text-gray-700 text-sm mb-4">
              Join our exclusive WhatsApp community for personalized mentor guidance and support on your journey to
              personal growth.
            </p>

            <button
              onClick={handleJoinClick}
              className="w-full py-2 px-4 bg-green-500 hover:bg-green-600 text-white rounded-md flex items-center justify-center transition-colors"
            >
              <Lightbulb className="h-4 w-4 mr-2" />
              Access Mentor Support
            </button>
          </div>
        </div>
      )}

      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className={`flex items-center justify-center w-16 h-16 rounded-full shadow-lg transition-all duration-300 ${
          isExpanded ? "bg-red-500 rotate-90" : "bg-green-500 hover:bg-green-600"
        }`}
      >
        {isExpanded ? <X className="h-8 w-8 text-white" /> : <Users className="h-8 w-8 text-white" />}

        {/* Pulse effect when closed */}
        {!isExpanded && (
          <span className="absolute w-full h-full rounded-full bg-green-500 animate-ping opacity-75"></span>
        )}
      </button>
    </div>
  )
}
