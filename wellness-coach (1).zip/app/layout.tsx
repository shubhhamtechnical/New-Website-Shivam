import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Lato, Cormorant_Garamond } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"

const lato = Lato({
  weight: ["300", "400", "700"],
  subsets: ["latin"],
  display: "swap",
  variable: "--font-lato",
})

const cormorant = Cormorant_Garamond({
  weight: ["400", "500", "600", "700"],
  subsets: ["latin"],
  display: "swap",
  variable: "--font-cormorant",
})

export const metadata: Metadata = {
  title: "Happier Women | Charu Lata Gupta",
  description: "Transform your life with Charu Lata Gupta, helping women lead a life full of purpose and happiness.",
  openGraph: {
    title: "Happier Women | Charu Lata Gupta",
    description: "Transform your life with Charu Lata Gupta, helping women lead a life full of purpose and happiness.",
    images: ["/og-image.png"],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${lato.variable} ${cormorant.variable}`}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
