"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"

interface ParallaxImageProps {
  src: string
  alt: string
  speed?: number
  className?: string
  priority?: boolean
}

export default function ParallaxImage({ src, alt, speed = 0.2, className = "", priority = false }: ParallaxImageProps) {
  const [offset, setOffset] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const [isInView, setIsInView] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return

      const rect = ref.current.getBoundingClientRect()
      const isVisible = rect.top < window.innerHeight && rect.bottom > 0

      if (isVisible) {
        setIsInView(true)
        const scrollPosition = window.scrollY
        const elementPosition = rect.top + scrollPosition
        const relativeScroll = scrollPosition - elementPosition
        setOffset(relativeScroll * speed)
      } else if (isInView) {
        setIsInView(false)
      }
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    handleScroll() // Initial check

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [speed, isInView])

  return (
    <div ref={ref} className={`relative overflow-hidden ${className}`}>
      <div
        style={{
          transform: `translateY(${offset}px)`,
          height: `calc(100% + ${Math.abs(speed) * 100}px)`,
          marginTop: speed < 0 ? `${Math.abs(speed) * 100}px` : "0",
        }}
        className="w-full relative"
      >
        <Image src={src || "/placeholder.svg"} alt={alt} fill className="object-cover" priority={priority} />
      </div>
    </div>
  )
}
