"use client"

import { useState, useEffect, useRef, type RefObject } from "react"

interface UseParallaxOptions {
  speed?: number
  threshold?: number
  direction?: "vertical" | "horizontal"
}

interface UseParallaxReturn {
  ref: RefObject<HTMLElement>
  style: {
    transform: string
  }
  inView: boolean
}

export function useParallax<T extends HTMLElement = HTMLDivElement>(
  options: UseParallaxOptions = {},
): UseParallaxReturn {
  const { speed = 0.1, threshold = 0.1, direction = "vertical" } = options

  const ref = useRef<T>(null)
  const [scrollPosition, setScrollPosition] = useState(0)
  const [inView, setInView] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (ref.current) {
        const rect = ref.current.getBoundingClientRect()
        const windowHeight = window.innerHeight
        const isVisible = rect.top < windowHeight * (1 - threshold) && rect.bottom > windowHeight * threshold

        setInView(isVisible)

        if (isVisible) {
          setScrollPosition(window.scrollY)
        }
      }
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    handleScroll() // Check initial position

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [threshold])

  const transform =
    direction === "vertical" ? `translateY(${scrollPosition * speed}px)` : `translateX(${scrollPosition * speed}px)`

  return {
    ref,
    style: {
      transform,
    },
    inView,
  }
}

export default useParallax
