import TextCutout from "./text-cutout"
import { Users, BookOpen, Mic } from "lucide-react"

export default function CutoutServices() {
  const services = [
    {
      icon: <Users className="h-8 w-8 text-[#F2E2D7]" />,
      title: "One-on-One Coaching",
      description: "Personalized coaching sessions tailored to your unique needs and goals.",
      pattern: "gradient",
    },
    {
      icon: <Mic className="h-8 w-8 text-black" />,
      title: "Motivational Speaking",
      description: "Engaging talks designed to inspire and empower your team or organization.",
      pattern: "noise",
    },
    {
      icon: <BookOpen className="h-8 w-8 text-[#F2E2D7]" />,
      title: "Published Works",
      description: "Transformative books and resources to guide your personal development journey.",
      pattern: "waves",
    },
  ]

  return (
    <section className="py-24 bg-[#F2E2D7]">
      <div className="container mx-auto px-4">
        {/* Section title with cut-out effect */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-black text-sm tracking-[0.2em] uppercase mb-2 font-light">What I Offer</h2>

          <TextCutout
            text="Premium Services"
            backgroundPattern="noise"
            className="h-[80px] md:h-[120px] flex items-center justify-center"
            textClassName="text-3xl md:text-5xl lg:text-6xl font-serif text-center"
            animate={true}
          />

          <p className="text-black/70 mt-6">
            Discover the range of services designed to help you achieve your full potential and transform your life.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          {services.map((service, index) => (
            <div
              key={index}
              className={`${
                index % 2 === 0 ? "bg-[#000000]" : "bg-[#F2E2D7] border border-black/10"
              } p-8 rounded-lg shadow-lg relative overflow-hidden group`}
            >
              {/* Service icon */}
              <div
                className={`w-16 h-16 ${
                  index % 2 === 0 ? "bg-[#F2E2D7]/10" : "bg-black/10"
                } rounded-full flex items-center justify-center mb-6 relative group-hover:scale-110 transition-transform duration-300`}
              >
                {service.icon}
                <div className="absolute inset-0 border border-[#F2E2D7]/10 rounded-full"></div>
              </div>

              {/* Service title with cut-out effect */}
              <TextCutout
                text={service.title}
                backgroundPattern={service.pattern as any}
                className="h-[60px] flex items-center mb-4"
                textClassName="text-xl font-serif"
                animate={true}
              />

              {/* Service description */}
              <p className={index % 2 === 0 ? "text-[#F2E2D7]/70" : "text-black/70"}>{service.description}</p>

              {/* Learn more button */}
              <div className="mt-6">
                <button
                  className={`px-4 py-2 ${
                    index % 2 === 0 ? "bg-[#F2E2D7] text-black" : "bg-black text-[#F2E2D7]"
                  } rounded-full text-sm font-medium tracking-wide hover:opacity-90 transition-all duration-300 relative`}
                >
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
