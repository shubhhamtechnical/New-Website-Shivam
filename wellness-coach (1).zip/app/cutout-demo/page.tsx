import CutoutHero from "@/components/cutout-hero"
import CutoutServices from "@/components/cutout-services"
import CutoutSectionTitle from "@/components/cutout-section-title"

export default function CutoutDemo() {
  return (
    <main className="min-h-screen">
      <CutoutHero />

      <section className="py-24 bg-[#F2E2D7]">
        <div className="container mx-auto px-4">
          <CutoutSectionTitle
            title="Client Experiences"
            subtitle="Testimonials"
            backgroundPattern="dots"
            theme="light"
          />

          <p className="text-black/70 text-center max-w-2xl mx-auto">
            Hear from those who have experienced the power of personalized coaching and transformed their lives.
          </p>
        </div>
      </section>

      <CutoutServices />

      <section className="py-24 bg-[#000000]">
        <div className="container mx-auto px-4">
          <CutoutSectionTitle title="Published Author" subtitle="My Book" backgroundImage="/book.jpg" theme="dark" />

          <p className="text-[#F2E2D7]/70 text-center max-w-2xl mx-auto">
            Discover the secrets to happiness in my published book, filled with practical tools and techniques.
          </p>
        </div>
      </section>
    </main>
  )
}
