import { Users, Lightbulb, Shield, BookOpen } from "lucide-react"
import Image from "next/image"

export default function CommunitySection() {
  return (
    <section className="py-20 bg-[#F2E2D7] relative overflow-hidden">
      <div className="absolute top-0 left-1/2 w-[1px] h-[40px] bg-white/10 transform -translate-x-1/2"></div>
      <div className="absolute bottom-0 left-1/2 w-[1px] h-[40px] bg-white/10 transform -translate-x-1/2"></div>

      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-[10%] right-[10%] w-64 h-64 rounded-full bg-[#E0F7F6]/20 blur-xl"></div>
        <div className="absolute bottom-[20%] left-[5%] w-48 h-48 rounded-full bg-[#E0F7F6]/10 blur-lg"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="w-16 h-16 bg-[#E0F7F6] rounded-full flex items-center justify-center mb-6 mx-auto relative">
              <Users className="h-8 w-8 text-black" />
              {/* Circular wire element */}
              <div className="absolute inset-0 border border-black/10 rounded-full"></div>
            </div>
            <h2 className="text-black text-sm tracking-[0.2em] uppercase mb-2 font-light">Expert Guidance</h2>
            <h3 className="font-serif text-3xl md:text-4xl lg:text-5xl mb-6 text-black">Mentor Support Community</h3>
            <p className="text-black/70 max-w-2xl mx-auto">
              Connect with our exclusive WhatsApp community where experienced mentors provide personalized guidance,
              practical strategies, and create a supportive environment for women to grow and transform.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-black/10">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 flex flex-col justify-center">
                <h4 className="font-serif text-2xl mb-4 text-black">What You'll Get</h4>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-[#E0F7F6] rounded-full flex items-center justify-center mr-3 mt-1 relative">
                      <span className="text-black text-xs">✓</span>
                      <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                    </div>
                    <p className="text-black/80">Personalized Mentor guidance and feedback</p>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-[#E0F7F6] rounded-full flex items-center justify-center mr-3 mt-1 relative">
                      <span className="text-black text-xs">✓</span>
                      <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                    </div>
                    <p className="text-black/80">Practical strategies for personal growth</p>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-[#E0F7F6] rounded-full flex items-center justify-center mr-3 mt-1 relative">
                      <span className="text-black text-xs">✓</span>
                      <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                    </div>
                    <p className="text-black/80">Support from experienced mentor</p>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-[#E0F7F6] rounded-full flex items-center justify-center mr-3 mt-1 relative">
                      <span className="text-black text-xs">✓</span>
                      <div className="absolute inset-0 border border-black/10 rounded-full"></div>
                    </div>
                    <p className="text-black/80">Priority access to workshops and resources</p>
                  </li>
                </ul>

                <a
                  href="https://chat.whatsapp.com/CXywwWRIoJz7K61E0uqE2V"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-8 inline-flex items-center justify-center px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-md transition-colors"
                >
                  <Lightbulb className="h-5 w-5 mr-2" />
                  Connect With Mentors
                </a>
              </div>

              <div className="bg-[#E0F7F6]/30 p-8 flex items-center justify-center relative">
                <div className="absolute inset-0 bg-[url('/noise-pattern.png')] opacity-5"></div>
                <div className="relative z-10 text-center">
                  <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <Image
                      src="/happierwomen_logo.png"
                      alt="Happier Women Logo"
                      width={80}
                      height={80}
                      className="rounded-full"
                    />
                  </div>
                  <h5 className="font-serif text-xl mb-2 text-black">Mentor-Led Community</h5>
                  <p className="text-black/70 mb-6">Access expert guidance from experienced mentors</p>

                  <div className="grid grid-cols-3 gap-4 max-w-xs mx-auto">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-[#D1F2F0] rounded-full flex items-center justify-center mx-auto mb-2">
                        <Lightbulb className="h-6 w-6 text-black/70" />
                      </div>
                      <p className="text-xs text-black/70">Expert Guidance</p>
                    </div>
                    <div className="text-center">
                      <div className="w-12 h-12 bg-[#D1F2F0] rounded-full flex items-center justify-center mx-auto mb-2">
                        <Shield className="h-6 w-6 text-black/70" />
                      </div>
                      <p className="text-xs text-black/70">Safe Space</p>
                    </div>
                    <div className="text-center">
                      <div className="w-12 h-12 bg-[#D1F2F0] rounded-full flex items-center justify-center mx-auto mb-2">
                        <BookOpen className="h-6 w-6 text-black/70" />
                      </div>
                      <p className="text-xs text-black/70">Growth Resources</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
