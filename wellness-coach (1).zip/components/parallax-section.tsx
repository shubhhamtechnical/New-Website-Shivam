"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"

export default function ParallaxSection() {
  const [scrollY, setScrollY] = useState(0)
  const sectionRef = useRef<HTMLDivElement>(null)
  const [inView, setInView] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect()
        const isInView = rect.top < window.innerHeight && rect.bottom > 0

        if (isInView) {
          setInView(true)
          setScrollY(window.scrollY)
        } else if (inView) {
          setInView(false)
        }
      }
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    handleScroll() // Check initial position

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [inView])

  // Calculate parallax positions based on scroll
  const calculateParallax = (speed: number) => {
    if (!inView) return 0
    return scrollY * speed
  }

  return (
    <section
      ref={sectionRef}
      className="relative h-[100vh] overflow-hidden bg-[#000000]"
      aria-label="Wellness journey parallax section"
    >
      {/* Background layer - slowest movement */}
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          transform: `translateY(${calculateParallax(0.05)}px)`,
          opacity: 0.7,
        }}
      >
        <Image src="/cosmic-fracture.png" alt="" fill className="object-cover" priority aria-hidden="true" />
      </div>

      {/* Middle layer - medium movement */}
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          transform: `translateY(${calculateParallax(0.15)}px)`,
        }}
      >
        <div className="absolute left-[10%] top-[20%] w-64 h-64 rounded-full bg-[#F2E2D7]/10 blur-xl"></div>
        <div className="absolute right-[15%] bottom-[30%] w-80 h-80 rounded-full bg-[#F2E2D7]/5 blur-xl"></div>

        {/* Decorative elements */}
        <div className="absolute left-[20%] top-[30%] w-[1px] h-[40%] bg-[#F2E2D7]/20"></div>
        <div className="absolute right-[25%] top-[20%] w-[1px] h-[60%] bg-[#F2E2D7]/15"></div>
        <div className="absolute left-[40%] bottom-[10%] w-[30%] h-[1px] bg-[#F2E2D7]/20"></div>
      </div>

      {/* Foreground layer - fastest movement */}
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          transform: `translateY(${calculateParallax(0.25)}px)`,
        }}
      >
        <div className="absolute left-[5%] bottom-[20%] w-32 h-32 rounded-full border border-[#F2E2D7]/30"></div>
        <div className="absolute right-[10%] top-[25%] w-24 h-24 rounded-full border border-[#F2E2D7]/20"></div>
      </div>

      {/* Content layer - fixed position */}
      <div className="relative h-full flex items-center justify-center z-10">
        <div className="text-center max-w-3xl mx-auto px-4">
          <h2
            className="text-[#F2E2D7] text-sm tracking-[0.2em] uppercase mb-4 font-light"
            style={{
              transform: `translateY(${calculateParallax(-0.1)}px)`,
              opacity: inView ? 1 : 0,
              transition: "opacity 0.5s ease-in-out",
            }}
          >
            Begin Your Journey
          </h2>
          <h3
            className="font-serif text-4xl md:text-5xl lg:text-6xl mb-8 text-[#F2E2D7]"
            style={{
              transform: `translateY(${calculateParallax(-0.15)}px)`,
              opacity: inView ? 1 : 0,
              transition: "opacity 0.5s ease-in-out 0.2s",
            }}
          >
            Transform Your Life Through <span className="italic">Mindful</span> Coaching
          </h3>
          <p
            className="text-[#F2E2D7]/80 text-lg mb-12 max-w-2xl mx-auto"
            style={{
              transform: `translateY(${calculateParallax(-0.2)}px)`,
              opacity: inView ? 1 : 0,
              transition: "opacity 0.5s ease-in-out 0.4s",
            }}
          >
            Embark on a transformative journey to discover your true potential. Through personalized coaching, you'll
            develop the tools and mindset needed to overcome challenges and create a life of purpose and fulfillment.
          </p>
          <div
            style={{
              transform: `translateY(${calculateParallax(-0.25)}px)`,
              opacity: inView ? 1 : 0,
              transition: "opacity 0.5s ease-in-out 0.6s",
            }}
          >
            <button
              className="px-8 py-3 bg-[#F2E2D7] text-black rounded-full text-sm font-medium tracking-wide hover:bg-[#F2E2D7]/90 transition-all duration-300 relative"
              onClick={() =>
                window.open(
                  `https://wa.me/919259686545?text=Hello, I'm interested in your coaching services.`,
                  "_blank",
                )
              }
            >
              Start Your Journey
            </button>
          </div>
        </div>
      </div>

      {/* Accessibility enhancement: Skip parallax section for screen readers */}
      <div className="sr-only">
        <a href="#content-after-parallax" className="focus:not-sr-only">
          Skip parallax section
        </a>
      </div>
    </section>
  )
}
