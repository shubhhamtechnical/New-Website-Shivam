"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MessageSquare } from "lucide-react"

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubmitted(true)

      // Prepare WhatsApp message with ALL form data
      const formattedMessage = `
*New Inquiry from Website*
---------------------------
*Name:* ${formData.name}
*Email:* ${formData.email}
*Phone:* ${formData.phone}
*Message:* ${formData.message}
      `.trim()

      const encodedMessage = encodeURIComponent(formattedMessage)

      // Open WhatsApp with pre-filled message containing all form details
      window.open(`https://wa.me/919259686545?text=${encodedMessage}`, "_blank")

      // Reset form
      setFormData({
        name: "",
        email: "",
        phone: "",
        message: "",
      })

      // Reset submission status after a delay
      setTimeout(() => {
        setIsSubmitted(false)
      }, 5000)
    }, 1000)
  }

  return (
    <div className="w-full max-w-md mx-auto">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-black text-sm font-medium mb-1">
            Your Name
          </label>
          <Input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter your name"
            required
            className="bg-white/80 border-black/20 focus:border-black"
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-black text-sm font-medium mb-1">
            Email Address
          </label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Enter your email"
            required
            className="bg-white/80 border-black/20 focus:border-black"
          />
        </div>

        <div>
          <label htmlFor="phone" className="block text-black text-sm font-medium mb-1">
            Phone Number
          </label>
          <Input
            id="phone"
            name="phone"
            type="tel"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Enter your phone number"
            className="bg-white/80 border-black/20 focus:border-black"
          />
        </div>

        <div>
          <label htmlFor="message" className="block text-black text-sm font-medium mb-1">
            Your Message
          </label>
          <Textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            placeholder="How can I help you?"
            rows={4}
            className="bg-white/80 border-black/20 focus:border-black"
          />
        </div>

        <Button
          type="submit"
          disabled={isSubmitting || isSubmitted}
          className="w-full bg-[#000000] hover:bg-black/80 text-[#F2E2D7] flex items-center justify-center gap-2"
        >
          {isSubmitting ? (
            <span className="flex items-center gap-2">
              <span className="h-4 w-4 border-2 border-t-transparent border-white rounded-full animate-spin"></span>
              Sending...
            </span>
          ) : isSubmitted ? (
            "Message Sent!"
          ) : (
            <>
              <MessageSquare className="h-4 w-4" />
              <span>Send Message</span>
            </>
          )}
        </Button>

        <div className="text-center text-black/60 text-sm mt-4">
          <p>All details will be sent directly to our team</p>
          <p className="font-medium mt-1">+91 9259686545</p>
        </div>
      </form>
    </div>
  )
}
